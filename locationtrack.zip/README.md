# Location Tracker

A web application that allows you to create tracking links that capture the GPS coordinates of visitors who open them.

## Features

- Create custom tracking links with names for easy identification
- Track visitor locations with precise GPS coordinates
- View visitor data including latitude, longitude, IP address, and user agent
- Visualize visitor locations on an interactive map
- Copy tracking links to clipboard with one click

## Prerequisites

- Node.js (v12 or higher)
- npm or yarn

## Installation

1. Clone this repository:
   ```
   git clone https://github.com/yourusername/location-tracker.git
   cd location-tracker
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Configure the Google Maps API:
   - Get a Google Maps API key from [Google Cloud Platform](https://developers.google.com/maps/documentation/javascript/get-api-key)
   - Replace `YOUR_API_KEY` in the `public/index.html` file with your actual API key

## Running the Application

Start the server:
```
npm start
```

For development with auto-restart:
```
npm run dev
```

The application will be available at http://localhost:3000

## Usage

1. Create a tracking link:
   - Enter a name for your tracking link
   - Click "Create Link"
   - Copy the generated URL to share with your intended targets

2. View tracking data:
   - Click on a link in the "Your Tracking Links" section
   - View visitor locations on the map and in the table below
   - Each entry shows the GPS coordinates, IP address, and browser information

## How It Works

When someone opens a tracking link:
1. The browser requests location permission
2. If granted, the precise GPS coordinates are captured
3. The data is sent to the server and stored in the database
4. You can view this data in real-time on your dashboard

## Security & Privacy

This application is for educational purposes only. Always:
- Get proper consent before tracking someone's location
- Comply with data privacy laws (GDPR, CCPA, etc.)
- Secure your server and database to protect collected information

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Disclaimer

This tool should only be used for legitimate purposes with explicit consent from the tracked individuals. The author(s) are not responsible for any misuse of this application. 